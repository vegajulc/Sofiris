public class Dama extends Fichas {
    public Dama (String nombre,String color,String posicionF, String posicionC  ) {
        super(nombre, color, posicionF,posicionC);
    }
}

