public class Rey extends Fichas {
    public Rey (String nombre,String color,String posicionF, String posicionC  ) {
        super(nombre, color, posicionF,posicionC);
    }
}
