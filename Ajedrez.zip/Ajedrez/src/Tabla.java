import javax.swing.*;
import java.awt.*;

public class Tabla extends javax.swing.JFrame {
    private javax.swing.JPanel jPanel1;
    Graphics g; int xy;
    public Tabla(String titulo) {
        initComponents();
        this.setTitle(titulo);
        this.setBounds(0, 0, 512, 512);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.jPanel1 =  (JPanel) this.getContentPane();
        this.jPanel1.setBounds(0, 0, 512, 512);
        this.jPanel1.setBackground(new java.awt.Color(190, 190, 190));
        jPanel1.setLayout(null);
        //jPanel1.setBackground(Color.lightGray);
        this.jPanel1.getGraphics();
        this.jPanel1.getWidth();
    }

    private void initComponents() {
    }

    //private void jPanel1MouseClicked(java.awt.event.MouseEvent evt) {
       // Dibujar t = new Dibujar(g, xy);
    //}





}