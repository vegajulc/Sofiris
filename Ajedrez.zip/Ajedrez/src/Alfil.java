public class Alfil extends Fichas {
    public Alfil (String nombre,String color,String posicionF, String posicionC  ) {
        super(nombre, color, posicionF,posicionC);
    }
}
