public class Caballo extends Fichas {
    public Caballo (String nombre,String color,String posicionF, String posicionC  ) {
        super(nombre, color, posicionF,posicionC);
    }
}
